 <?php
 $link = mysqli_connect("localhost","root","","project1") or
                    die("unable to connect ".mysqli_connect_error());
 ?>